package game;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class Main {
    private JPanel panelMain;
    private int seconds = 0;
    private int vidas = 5;
    private int puntos = 0;
    private JPanel panelTitle;
    private JLabel labelTime;
    private JLabel labelVidas;
    private JLabel labelPuntos;
    private JButton buttonVerPuntos;
    private JPanel panelCenter;
    private JButton buttonPause;
    private JButton buttonAdivinar;
    private JTextField textAreaNumeroUsuario;  // TextField para entrada de número
    private Timer timer;

    public Main() {
        panelMain = new JPanel(null);
        panelMain.setPreferredSize(new Dimension(800, 600));
        showPanelTitle();
        showPanelCenter();
        startTimer();
    }

    private void showPanelTitle() {
        panelTitle = new JPanel();
        panelTitle.setBounds(0, 0, 800, 50);
        panelTitle.setBackground(Color.GRAY);
        panelMain.add(panelTitle);

        labelTime = new JLabel("0 segundos");
        panelTitle.add(labelTime);

        labelVidas = new JLabel(" Vidas: " + vidas);
        panelTitle.add(labelVidas);

        labelPuntos = new JLabel(" Puntos: " + puntos);
        panelTitle.add(labelPuntos);

        buttonVerPuntos = new JButton("Ver puntos");
        buttonVerPuntos.setBackground(new Color(25, 18, 50));
        buttonVerPuntos.setForeground(Color.WHITE);
        buttonVerPuntos.addActionListener(e -> mostrarDatosBD());
        panelTitle.add(buttonVerPuntos);
    }

    private void showPanelCenter() {
        panelCenter = new JPanel(null);
        panelCenter.setBounds(0, 50, 800, 550);
        panelCenter.setBackground(Color.LIGHT_GRAY);
        panelMain.add(panelCenter);

        buttonPause = new JButton("Pausa");
        buttonPause.setBounds(50, 50, 120, 30);
        buttonPause.setBackground(new Color(25, 18, 50));
        buttonPause.setForeground(Color.WHITE);
        buttonPause.addActionListener(e -> {
            if (buttonPause.getText().equals("Pausa")) {
                timer.stop();
                buttonPause.setText("Reanudar");
            } else {
                timer.start();
                buttonPause.setText("Pausa");
            }
        });
        panelCenter.add(buttonPause);

        textAreaNumeroUsuario = new JTextField();
        textAreaNumeroUsuario.setBounds(50, 100, 200, 30);
        panelCenter.add(textAreaNumeroUsuario);

        buttonAdivinar = new JButton("Adivina el número");
        buttonAdivinar.setBounds(50, 150, 180, 30);
        buttonAdivinar.setBackground(new Color(25, 18, 50));
        buttonAdivinar.setForeground(Color.WHITE);
        buttonAdivinar.addActionListener(e -> verificarNumero());
        panelCenter.add(buttonAdivinar);
    }

    private void verificarNumero() {
        try {
            int guess = Integer.parseInt(textAreaNumeroUsuario.getText());
            String mensaje;
            if (guess == 50) {
                puntos++;
                mensaje = "Has acertado";
            } else if (guess < 50) {
                vidas--;
                puntos--;
                mensaje = "El número introducido es más pequeño";
            } else {
                vidas--;
                puntos--;
                mensaje = "El número introducido es más grande";
            }

            if (vidas < 0) {
                mensaje = "Has perdido";
            }

            JOptionPane.showMessageDialog(null, mensaje);

            labelPuntos.setText(" Puntos: " + puntos);
            labelVidas.setText(" Vidas: " + vidas);

            String name = JOptionPane.showInputDialog("Introduce tu nombre:");
            if (name != null && !name.isEmpty()) {
                guardarDatosBD(name, vidas, puntos);
            }

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Por favor introduce un número válido.");
        }
    }

    private void guardarDatosBD(String name, int vidas, int puntos) {
        String url = "jdbc:mysql://localhost:3306/juegoAdivinarNumero";
        String user = "root";
        String password = "mysql";
        String insert = "INSERT INTO partidas (id, nombreJugador, vidas, puntos, segundos) VALUES (?, ?, ?, ?, ?)";

        try (Connection con = DriverManager.getConnection(url, user, password);
             PreparedStatement ps = con.prepareStatement(insert)) {

            ps.setInt(1, 1);
            ps.setString(2, name);
            ps.setInt(3, vidas);
            ps.setInt(4, puntos);
            ps.setInt(5, seconds);
            ps.executeUpdate();
        } catch (Exception e) {
            System.out.println("Error al guardar datos: " + e.getMessage());
        }
    }

    private void mostrarDatosBD() {
        String url = "jdbc:mysql://localhost:3306/juegoAdivinarNumero";
        String user = "root";
        String password = "mysql";
        String query = "SELECT * FROM partidas";

        try (Connection con = DriverManager.getConnection(url, user, password);
             PreparedStatement ps = con.prepareStatement(query);
             ResultSet rs = ps.executeQuery()) {

            StringBuilder result = new StringBuilder("Partidas guardadas:\n");
            while (rs.next()) {
                result.append(rs.getInt(1)).append(" - ")
                        .append(rs.getString(2)).append(" - ")
                        .append(rs.getInt(3)).append(" - ")
                        .append(rs.getInt(4)).append(" - ")
                        .append(rs.getInt(5)).append("\n");
            }

            JOptionPane.showMessageDialog(null, result.toString());
        } catch (Exception e) {
            System.out.println("Error al mostrar datos: " + e.getMessage());
        }
    }

    private void startTimer() {
        timer = new Timer(1000, e -> {
            seconds++;
            labelTime.setText(seconds + " segundos");
        });
        timer.start();
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Juego Adivina el Número");
        Main mainInstance = new Main();
        frame.setContentPane(mainInstance.panelMain);
        frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);

        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                int close = JOptionPane.showConfirmDialog(null,
                        "¿Seguro que quieres salir?", "Confirmación", JOptionPane.YES_NO_OPTION);
                if (close == JOptionPane.YES_OPTION) {
                    frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
                }
            }
        });
    }
}